
package appestoque;

import interfaces.Login;
import interfaces.Principal;

public class AppEstoque {

    public static void main(String[] args) {
        // TODO code application logic here
        Login l = new Login();
        l.setVisible(true);
    }
    
}
